<?= $this->extend('layouts/main_layout'); ?>
<?= $this->section('content'); ?>
<h1>Lacak Status</h1>
<p>Halaman ini untuk pelacakan status mutasi oleh guru.</p>
<?= $this->endSection(); ?>
