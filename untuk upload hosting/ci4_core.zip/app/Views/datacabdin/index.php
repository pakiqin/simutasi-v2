<?= $this->extend('layouts/main_layout'); ?>
<?= $this->section('content'); ?>

<h1 class="h3 mb-4 text-gray-800">
    <i class="fas fa-building"></i> Daftar Cabang Dinas
</h1>

<?php if (session()->getFlashdata('message')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?= session()->getFlashdata('message'); ?>
        </button>
    </div>
<?php endif; ?>

<div class="d-flex justify-content-between align-items-center mb-3 flex-wrap">
    <a href="/cabang-dinas/create" class="btn btn-primary mb-2">
        <i class="fas fa-plus-circle"></i> Tambah Cabang Dinas
    </a>
    <div class="d-flex align-items-center">
        <label for="per_page" class="me-2 mb-0">Tampilkan:</label>
        <select id="per_page" class="form-select form-select-sm" style="width: auto;" onchange="updatePerPage()">
            <option value="5" <?= $perPage == 5 ? 'selected' : '' ?>>5</option>
            <option value="10" <?= $perPage == 10 ? 'selected' : '' ?>>10</option>
            <option value="25" <?= $perPage == 25 ? 'selected' : '' ?>>25</option>
            <option value="50" <?= $perPage == 50 ? 'selected' : '' ?>>50</option>
        </select>
    </div>
</div>

<table class="table table-striped">
    <thead>
        <tr>
            <th>No.</th>
            <th>Kode Cabang</th>
            <th>Nama Cabang</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php 
        $no = 1 + ($perPage * ($pager->getCurrentPage('cabang_dinas') - 1));
        foreach ($cabang_dinas as $row): ?>
            <tr>
                <td><?= $no++; ?></td>
                <td><?= $row['kode_cabang']; ?></td>
                <td><?= $row['nama_cabang']; ?></td>
                <td>
                    <a href="/cabang-dinas/edit/<?= $row['id']; ?>" class="btn btn-warning btn-sm">
                        <i class="fas fa-edit"></i> Edit
                    </a>
                    <a href="/cabang-dinas/delete/<?= $row['id']; ?>" 
                       class="btn btn-danger btn-sm" 
                       onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?');">
                        <i class="fas fa-trash-alt"></i> Hapus
                    </a>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>

<div class="d-flex justify-content-between align-items-center">
    <p class="mb-0">Menampilkan <?= count($cabang_dinas); ?> dari <?= $pager->getTotal('cabang_dinas'); ?> data</p>
    <?= $pager->links('cabang_dinas', 'custom_pagination'); ?>
</div>

<script>
    // Fungsi untuk mengupdate jumlah data per halaman
    function updatePerPage() {
        const perPage = document.getElementById('per_page').value;
        const url = new URL(window.location.href);
        url.searchParams.set('per_page', perPage);
        window.location.href = url.toString();
    }
</script>

<?= $this->endSection(); ?>
