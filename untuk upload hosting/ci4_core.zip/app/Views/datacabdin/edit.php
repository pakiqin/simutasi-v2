<?= $this->extend('layouts/main_layout'); ?>
<?= $this->section('content'); ?>

<h1 class="h3 mb-4 text-gray-800">Edit Cabang Dinas</h1>

<!-- Tampilkan Pesan Error Jika Ada -->
<?php if (session()->get('error')): ?>
    <div class="alert alert-danger" role="alert">
        <?= session()->get('error'); ?>
    </div>
<?php endif; ?>

<div class="row">
    <div class="col-lg-6">
        <form action="/cabang-dinas/update/<?= $cabang_dinas['id'] ?>" method="post">
            <div class="mb-3">
                <label for="kode_cabang" class="form-label">Kode Cabang</label>
                <div class="input-group">
                    <span class="input-group-text">
                        <i class="fas fa-code"></i> <!-- Ikon untuk Kode Cabang -->
                    </span>
                    <input type="text" name="kode_cabang" id="kode_cabang" class="form-control" 
                           value="<?= $cabang_dinas['kode_cabang']; ?>" required>
                </div>
            </div>
            <div class="mb-3">
                <label for="nama_cabang" class="form-label">Nama Cabang</label>
                <div class="input-group">
                    <span class="input-group-text">
                        <i class="fas fa-building"></i> <!-- Ikon untuk Nama Cabang -->
                    </span>
                    <input type="text" name="nama_cabang" id="nama_cabang" class="form-control" 
                           value="<?= $cabang_dinas['nama_cabang']; ?>" required>
                </div>
            </div>
            <div class="text-end">
                <a href="/cabang-dinas" class="btn btn-secondary me-2"><i class="fas fa-arrow-left"></i> Kembali</a>
                <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Simpan</button>
            </div>
        </form>
    </div>
</div>

<?= $this->endSection(); ?>
