<?= $this->extend('layouts/main_layout'); ?>
<?= $this->section('content'); ?>
<h1>Proses di Dinas</h1>
<p>Halaman ini untuk pengelolaan proses usulan di Dinas Provinsi.</p>
<?= $this->endSection(); ?>
