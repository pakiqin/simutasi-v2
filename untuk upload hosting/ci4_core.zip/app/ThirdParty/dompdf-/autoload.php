<?php

require_once __DIR__ . '/src/Autoloader.php';
Dompdf\Autoloader::register();
