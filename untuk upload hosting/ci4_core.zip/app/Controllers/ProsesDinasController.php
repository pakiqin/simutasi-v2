<?php

namespace App\Controllers;

class ProsesDinasController extends BaseController
{
    public function index()
    {
        return view('proses-dinas/index');
    }
}
