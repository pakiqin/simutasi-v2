<?php

namespace App\Controllers;

class LacakStatusController extends BaseController
{
    public function index()
    {
        return view('lacak-status/index');
    }
}
