<?php

namespace App\Controllers;

class Dashboard extends BaseController
{
    public function index()
    {
        return view('dashboard'); // Mengarah ke app/Views/dashboard.php
    }
}
