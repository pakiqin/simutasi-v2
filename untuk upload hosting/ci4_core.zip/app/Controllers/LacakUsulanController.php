<?php

namespace App\Controllers;

use App\Models\UsulanStatusHistoryModel;
use App\Models\UsulanModel;
use CodeIgniter\Controller;

class LacakUsulanController extends Controller
{
    public function index()
    {
        return view('lacak_mutasi'); // Menampilkan halaman landing page baru
    }

    public function search()
    {
        $nomorUsulan = $this->request->getGet('nomor_usulan');
        $nip = $this->request->getGet('nip');

        // Model untuk mencari data usulan guru
        $usulanModel = new UsulanModel();
        $historyModel = new UsulanStatusHistoryModel();

        // Cari informasi guru berdasarkan nomor usulan dan nip
        $usulan = $usulanModel->where('nomor_usulan', $nomorUsulan)
                              ->where('guru_nip', $nip)
                              ->first();

        // Jika tidak ditemukan, kembalikan ke halaman lacak dengan error
        if (!$usulan) {
            return redirect()->to('/lacak-mutasi')->with('error', 'Nomor usulan atau NIP tidak ditemukan!');
        }

        // Ambil riwayat status mutasi berdasarkan nomor usulan
        $results = $historyModel->where('nomor_usulan', $nomorUsulan)
                                ->orderBy('updated_at', 'DESC')
                                ->findAll();

        // Kirim data ke view hasil_lacak_mutasi.php
        return view('hasil_lacak_mutasi', [
            'nomorUsulan'   => $usulan['nomor_usulan'],
            'namaGuru'      => $usulan['guru_nama'],
            'nipGuru'       => $usulan['guru_nip'],
            'sekolahAsal'   => $usulan['sekolah_asal'],
            'sekolahTujuan' => $usulan['sekolah_tujuan'],
            'tanggalUsulan' => $usulan['created_at'],
            'results'       => $results
        ]);
    }
}
